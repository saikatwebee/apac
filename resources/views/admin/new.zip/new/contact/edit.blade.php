@extends('layouts.admin')
@section('content')
<style>
    label{
    font-weight: 700;
    color: #2c2e3e;
}
</style>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 m-b-30">
            <div class="d-block d-sm-flex flex-nowrap align-items-center">
                <div class="page-title mb-2 mb-sm-0">
                    <h1>{{$list_title}}</h1>
                </div>
                <div class="ml-auto d-flex align-items-center">
                    <nav>
                        <ol class="breadcrumb p-0 m-b-0">
                            <li class="breadcrumb-item">
                                <a href="{{ url('dashboard') }}"><i class="ti ti-home"></i></a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="{{ route('eidt-contact') }}">{{$list_title}}</a>
                            </li>
                            <li class="breadcrumb-item active text-primary" aria-current="page">{{$edit_title}}</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card py-5">
                <div class="col-12">
                    @include('inc.messages')
                </div>

                <form class="validate-form" method="POST" action="{{ route('update-contact',$contactinfo->id) }}" enctype="multipart/form-data">
                    @csrf

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">

                                <div class="form-group @error('name') has-error @enderror">
                                    <label for="name" class="control-label">{{ __('Name') }}<span class="text-danger">*</span></label>

                                        <input type="text" class="form-control" name="name" id="name" value="{{$contactinfo->name}}">
                                        @if($errors->has('name'))
                                            <p class="text-danger">{{ $errors->first('name') }}</p>
                                        @endif
                                </div>
                                <div class="form-group @error('phone_number') has-error @enderror">
                                    <label for="phone_number" class="control-label">{{ __('Mobile Number ') }}<span class="text-danger">*</span></label>

                                        <input type="text" class="form-control" name="phone_number" id="phone_number" value="{{$contactinfo->phone_number}}">
                                        @if($errors->has('phone_number'))
                                            <p class="text-danger">{{ $errors->first('phone_number') }}</p>
                                        @endif
                                </div>
                                <div class="form-group @error('message') has-error @enderror">
                                <label class="control-label text-bold" for="message">{{ __('Message') }}<span class="text-danger">*</span></label>

                                    {{-- <label for="description" class="control-label">{{ __('Description') }}</label> --}}
                                    <textarea class="form-control no-resize" name="message" id="message" rows="3" >{{$contactinfo->message}}</textarea>

                                        {{-- <input type="text" class="form-control" name="description" id="description" > --}}
                                        @if($errors->has('message'))
                                            <p class="text-danger">{{ $errors->first('message') }}</p>
                                        @endif
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group @error('address') has-error @enderror">
                                    <label class="control-label text-bold" for="address">{{ __('Address') }}<span class="text-danger">*</span></label>

                                        {{-- <label for="description" class="control-label">{{ __('Description') }}</label> --}}
                                        <textarea class="form-control no-resize" name="address" id="address" rows="3" >{{$contactinfo->address}}</textarea>

                                            {{-- <input type="text" class="form-control" name="description" id="description" > --}}
                                            @if($errors->has('address'))
                                                <p class="text-danger">{{ $errors->first('address') }}</p>
                                            @endif
                                    </div>
                                <div class="form-group @error('url') has-error @enderror">
                                    <label for="url" class="control-label">{{ __('Url') }}</label>

                                        <input type="text" class="form-control" name="url" id="url" value="{{$contactinfo->url}}">
                                        @if($errors->has('url'))
                                            <p class="text-danger">{{ $errors->first('url') }}</p>
                                        @endif
                                </div>
                                <div class="form-group @error('state') has-error @enderror">
                                    <label for="state" class="control-label">{{ __('Select State') }}</label>

                                        <input type="text" class="form-control" name="state" id="state" value="{{$contactinfo->state}}">
                                        @if($errors->has('state'))
                                            <p class="text-danger">{{ $errors->first('state') }}</p>
                                        @endif
                                </div>
                                <div class="form-group @error('branch') has-error @enderror">
                                    <label for="branch" class="control-label">{{ __('Select Branch') }}</label>

                                        <input type="text" class="form-control" name="branch" id="branch" value="{{$contactinfo->branch}}">
                                        @if($errors->has('branch'))
                                            <p class="text-danger">{{ $errors->first('branch') }}</p>
                                        @endif
                                </div>
                                <div class="form-group @error('pincode') has-error @enderror">
                                    <label for="pincode" class="control-label">{{ __('Search By Pincode') }}</label>

                                        <input type="text" class="form-control" name="pincode" id="pincode" value="{{$contactinfo->pincode}}">
                                        @if($errors->has('pincode'))
                                            <p class="text-danger">{{ $errors->first('pincode') }}</p>
                                        @endif
                                </div>

                            </div>






                        </div>
                    </div>
                    <div class="card-footer text-right">
                        <button class="btn btn-primary mr-1" type="submit">{{ __('Update') }}</button>
                        <a href="{{route('dashboard')}}" class="btn btn-secondary" type="reset">{{ __('Cancel') }}</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

@extends('layouts.admin')
@section('content')

<style>
    textarea{
      resize: none;
    }
    label{
      color: #212529;
    }
        .note-editor.note-frame .note-editing-area {
      height: 200px !important;
    }
    .note-editor.note-frame .note-editing-area .note-editable {
      height: 200px !important;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 m-b-30">
            <div class="d-block d-lg-flex flex-nowrap align-items-center">
                <div class="page-title mr-4 pr-4 border-right">
                    <h1>{{$footer_title}}</h1>
                </div>
                <div class="breadcrumb-bar align-items-center">
                    <nav>
                        <ol class="breadcrumb p-0 m-b-0">
                            <li class="breadcrumb-item">
                                <a href="{{ url('/admin/dashboard') }}"><i class="ti ti-home"></i></a>
                            </li>
                            <li class="breadcrumb-item active text-primary" aria-current="page">NewsLetter - Edit</li>
                        </ol>
                    </nav>
                </div>
                <div class="ml-auto d-flex align-items-center secondary-menu text-center">
                  <a href="{{ route('newsletter') }}" class="tooltip-wrapper" data-toggle="tooltip" data-placement="top" title="" data-original-title="Add Page">
                      <i class="fa fa-arrow-left btn btn-icon text-primary"  aria-hidden="true"></i>
                  </a>
              </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card card-statistics">



                <form class="validate-form" method="POST" action="{{route('newsletter.update',$newsletterinfo->id)}}" enctype="multipart/form-data">
                    @csrf

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8">

                                <div class="form-group @error('newsletter_title') has-error @enderror">
                                    <label for="newsletter_title" class="control-label">{{ __('Newsletter Title') }}<span class="text-danger">*</span></label>

                                        <input type="text" class="form-control" name="newsletter_title" id="newsletter_title"  value="{{$newsletterinfo->newsletter_title}}">
                                        @if($errors->has('newsletter_title'))
                                            <p class="text-danger">{{ $errors->first('newsletter_title') }}</p>
                                        @endif
                                </div>
                                <div class="form-group @error('newsletter_pdf_name') has-error @enderror">
                                    <label for="newsletter_pdf_name" class="control-label">{{ __('Newsletter PDF Name') }}<span class="text-danger">*</span></label>

                                        <input type="text" class="form-control" name="newsletter_pdf_name" id="newsletter_pdf_name" value="{{$newsletterinfo->newsletter_pdf_name}}">
                                        @if($errors->has('newsletter_pdf_name'))
                                            <p class="text-danger">{{ $errors->first('newsletter_pdf_name') }}</p>
                                        @endif
                                </div>
                                <div class="form-group @error('newsletter_pdf_file') has-error @enderror">
                                <label class="control-label text-bold" for="newsletter_pdf_file">{{ __('Newsletter PDF File') }}<span class="text-danger">*</span></label>

                                    <input id="newsletter_pdf_file" name="newsletter_pdf_file" class="form-control" type="file"  value="{{$newsletterinfo->newsletter_pdf_file}}"/>
                                        @if($errors->has('newsletter_pdf_file'))
                                            <p class="text-danger">{{ $errors->first('newsletter_pdf_file') }}</p>
                                        @endif
                                        <a href=" http://127.0.0.1:8002/uploads/newsletter/{{$newsletterinfo->newsletter_pdf_file}}" target="_blank" >
                                            <i class="fa fa-file" aria-hidden="true" style="font-size: 100px;" id="current_ic_image">
                                            </i>
                                        </a>

                                </div>

                            </div>


                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary w-100">Update</button>
                              </div>





                        </div>
                    </div>

                </form>


                </div>
            </div>
        </div>
    </div>
</div>

@endsection

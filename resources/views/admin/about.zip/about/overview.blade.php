@extends('layouts.admin')
@section('content')

<style>
  textarea{
    resize: none;
  }
label{
  color: #212529;
}
/* .note-editing-area{
  height: 432px;
} */
.note-editor.note-frame .note-editing-area {
  height: 330px !important;
}
.note-editor.note-frame .note-editing-area .note-editable {
  height: 330px !important;
}
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 m-b-30">
            <div class="d-block d-lg-flex flex-nowrap align-items-center">
                <div class="page-title mr-4 pr-4 border-right">
                    <h1>About Management</h1>
                </div>
                <div class="breadcrumb-bar align-items-center">
                    <nav>
                        <ol class="breadcrumb p-0 m-b-0">
                            <li class="breadcrumb-item">
                                <a href="{{ url('/admin/dashboard') }}"><i class="ti ti-home"></i></a>
                            </li>
                            <li class="breadcrumb-item active text-primary" aria-current="page">Overview</li>
                        </ol>
                    </nav>
                </div>
                
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card card-statistics">
                <div class="card-body">
                      <form action="{{route('overview.update')}}" method="post" enctype="multipart/form-data" autocomplete="off" id="about_form">
                        @csrf
                        @if (Session::has('msg')) 
                      <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-bottom: 10px;">
                        <strong>{{session::get('msg')}}</strong> 
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      @endif
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="ovr_desc">{{__('Overview Descrpition')}}</label>
                              <textarea class="summernote" name="ovr_desc" id="summernote">{{$overview->ovr_desc}}</textarea>

                            </div>
                          </div>

                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="aum">{{__('AUM')}}</label>
                              <input type="text" name="aum" id="aum"  class="form-control" value="{{$overview->aum}}">
                            </div>
                            <div class="form-group">
                              <label for="branches">{{__('Branches')}}</label>
                              <input type="text" name="branches" id="branches"  class="form-control" value="{{$overview->branches}}">
                            </div>

                            <div class="form-group">
                              <label for="states">{{__('States')}}</label>
                              <input type="text" name="states" id="states"  class="form-control" value="{{$overview->states}}">
                            </div>
                            <div class="form-group">
                              <label for="employees">{{__('Employees')}}</label>
                              <input type="text" name="employees" id="employees"  class="form-control" value="{{$overview->employees}}">
                            </div>
                            <div class="form-group">
                              <label for="customers">{{__('Customers')}}</label>
                              <input type="text" name="customers" id="customers"  class="form-control" value="{{$overview->customers}}">
                            </div>
                            <div class="form-group">
                              <label for="stable">{{__('Stable')}}</label>
                              <input type="text" name="stable" id="stable"  class="form-control" value="{{$overview->stable}}">
                            </div>
                          </div>
                          <div class="col-md-12 text-center">
                            <button type="submit" class="btn btn-primary w-100">Update</button>
                          </div>
                        </div>
                      </form>
                </div>
            </div>
        </div>
    </div>
</div>
 
@endsection
<script>
   var loadFile = function(event) {
    var output = document.getElementById('output');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src) // free memory
    }
  };
</script>
<script>
   $(document).ready(function() {
    $('.summernote').summernote({
      height: 300,
    });
  });
</script>
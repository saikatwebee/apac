@extends('layouts.admin')
@section('content')

<style>
    .size-16{
        width: 16px;
        height: 16px;
    }
    label{
    font-weight: 700;
    color: #2c2e3e;
}
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 m-b-30">
            <div class="d-block d-lg-flex flex-nowrap align-items-center">
                <div class="page-title mr-4 pr-4 border-right">
                    <h1>{{$home_page_title}}</h1>
                </div>
                <div class="breadcrumb-bar align-items-center">
                    <nav>
                        <ol class="breadcrumb p-0 m-b-0">
                            <li class="breadcrumb-item">
                                <a href="{{ url('dashboard') }}"><i class="ti ti-home"></i></a>
                            </li>
                            <li class="breadcrumb-item active text-primary" aria-current="page">{{$update_title}}</li>
                        </ol>
                    </nav>
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card py-5">
                <div class="col-12">
                    @include('inc.messages')
                </div>

                <form class="validate-form" method="POST" action="{{ route('home_page.update') }}" enctype="multipart/form-data">
                    @csrf

                    <div class="card-body">
                        <div class="p-3 text-center bg-none">
                            <h3 class="mb-3">{{__('Apac at a Glance')}}</h3>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group @error('glance_desc') has-error @enderror">
                                    <label for="glance_desc" class="control-label">{{ __('Glance Description') }}</label>
                                    <textarea class="form-control no-resize" name="glance_desc" id="glance_desc" rows="3" >{{$home_page_info->glance_desc}}</textarea>

                                        @if($errors->has('glance_desc'))
                                            <p class="text-danger">{{ $errors->first('glance_desc') }}</p>
                                        @endif
                                </div>
                            </div>
                        </div>

    {{--Apac at a Glance section ends  --}}

                        <div class="p-3 text-center bg-none">
                            <h3 class="mb-3">{{__('Data Points')}}</h3>
                          </div>

                          <div class="row">
                            <div class="col-md-6">
                                <div class="form-group @error('branches') has-error @enderror">
                                    <label for="branches" class="control-label">{{ __('Branches') }}</label>
                                    <input type="text" class="form-control" name="branches" id="branches" value="{{$home_page_info->branches}}">

                                        @if($errors->has('branches'))
                                            <p class="text-danger">{{ $errors->first('branches') }}</p>
                                        @endif
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group @error('states') has-error @enderror">
                                    <label for="states" class="control-label">{{ __('States') }}</label>
                                    <input type="text" class="form-control" name="states" id="states" value="{{$home_page_info->states}}">

                                        @if($errors->has('states'))
                                            <p class="text-danger">{{ $errors->first('states') }}</p>
                                        @endif
                                </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-md-6">
                                <div class="form-group @error('employees') has-error @enderror">
                                    <label for="employees" class="control-label">{{ __('Employees') }}</label>
                                    <input type="text" class="form-control" name="employees" id="employees" value="{{$home_page_info->employees}}">

                                        @if($errors->has('employees'))
                                            <p class="text-danger">{{ $errors->first('employees') }}</p>
                                        @endif
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group @error('customers') has-error @enderror">
                                    <label for="customers" class="control-label">{{ __('Customers') }}</label>
                                    <input type="text" class="form-control" name="customers" id="customers" value="{{$home_page_info->customers}}">

                                        @if($errors->has('customers'))
                                            <p class="text-danger">{{ $errors->first('customers') }}</p>
                                        @endif
                                </div>
                            </div>
                          </div>

    {{-- Data Points section ends --}}

                        <div class="p-3 text-center bg-none">
                            <h3 class="mb-3">{{__('Benefits Of Apac Loans')}}</h3>
                          </div>
                          <div class="row">
                            <div class="col-md-6">
                                <div class="form-group @error('points1') has-error @enderror">
                                    <label for="points1" class="control-label">{{ __('Benefits 1') }}</label>
                                    <input type="text" class="form-control" name="points1" id="points1" value="{{$home_page_info->points1}}">

                                        @if($errors->has('points1'))
                                            <p class="text-danger">{{ $errors->first('points1') }}</p>
                                        @endif
                                </div>
                                <div class="form-group @error('points2') has-error @enderror">
                                    <label for="points2" class="control-label">{{ __('Benefits 2') }}</label>
                                    <input type="text" class="form-control" name="points2" id="points2" value="{{$home_page_info->points2}}">

                                        @if($errors->has('points2'))
                                            <p class="text-danger">{{ $errors->first('points2') }}</p>
                                        @endif
                                </div>
                                <div class="form-group @error('points3') has-error @enderror">
                                    <label for="points3" class="control-label">{{ __('Benefits 3') }}</label>
                                    <input type="text" class="form-control" name="points3" id="points3" value="{{$home_page_info->points3}}">

                                        @if($errors->has('points3'))
                                            <p class="text-danger">{{ $errors->first('points3') }}</p>
                                        @endif
                                </div>

                            </div>
                            <div class="col-md-6">

                                <div class="form-group @error('points4') has-error @enderror">
                                    <label for="points4" class="control-label">{{ __('Benefits 4') }}</label>
                                    <input type="text" class="form-control" name="points4" id="points4" value="{{$home_page_info->points4}}">

                                        @if($errors->has('points4'))
                                            <p class="text-danger">{{ $errors->first('points4') }}</p>
                                        @endif
                                </div>
                                <div class="form-group @error('points5') has-error @enderror">
                                    <label for="points5" class="control-label">{{ __('Benefits 5') }}</label>
                                    <input type="text" class="form-control" name="points5" id="points5" value="{{$home_page_info->points5}}">

                                        @if($errors->has('points5'))
                                            <p class="text-danger">{{ $errors->first('points5') }}</p>
                                        @endif
                                </div>

                            </div>

                        </div>
    {{-- Benefits Of Apac Loans section ends --}}
                    </div>
                    <div class="card-footer ">
                        <button class="btn btn-primary btn-lg btn-block" type="submit">{{ __('Update') }}</button>
                        {{-- <a href="{{route('dashboard')}}" class="btn btn-secondary" type="reset">{{ __('Cancel') }}</a> --}}
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>

@endsection

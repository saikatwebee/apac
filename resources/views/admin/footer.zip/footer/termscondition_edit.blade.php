@extends('layouts.admin')
@section('content')

<style>
    .size-16{
        width: 16px;
        height: 16px;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 m-b-30">
            <div class="d-block d-lg-flex flex-nowrap align-items-center">
                <div class="page-title mr-4 pr-4 border-right">
                    <h1>{{$footer_title}}</h1>
                </div>
                <div class="breadcrumb-bar align-items-center">
                    <nav>
                        <ol class="breadcrumb p-0 m-b-0">
                            <li class="breadcrumb-item">
                                <a href="{{ url('dashboard') }}"><i class="ti ti-home"></i></a>
                            </li>
                            <li class="breadcrumb-item active text-primary" aria-current="page">{{$update_title}}</li>
                        </ol>
                    </nav>
                </div>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card py-5">
                <div class="col-12">
                    @include('inc.messages')
                </div>

                <form class="validate-form" method="POST" action="{{ route('terms_and_condition.update') }}" enctype="multipart/form-data">
                    @csrf

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">

                                <div class="form-group">
                                    <label class="control-label" for="">Terms and Condition<span class="text-danger">*</span></label>
                                    <textarea class="terms_condition" name="terms_condition" id="terms_condition">{{$terms_conditon_info->terms_condition}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="post">Limited License<span class="text-danger">*</span></label>
                                    <textarea class="limited_license" name="limited_license" id="limited_license">{{$terms_conditon_info->limited_license}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="post">Contents<span class="text-danger">*</span></label>
                                    <textarea class="contents" name="contents" id="contents">{{$terms_conditon_info->contents}}</textarea>
                                </div>
                                 <div class="form-group">
                                    <label class="control-label" for="post">Use of Services<span class="text-danger">*</span></label>
                                    <textarea class="use_service" name="use_service" id="use_service">{{$terms_conditon_info->use_service}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="intellectual_property">Intellectual Property<span class="text-danger">*</span></label>
                                    <textarea class="intellectual_property" name="intellectual_property" id="intellectual_property">{{$terms_conditon_info->intellectual_property}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="post">Confidential Information<span class="text-danger">*</span></label>
                                    <textarea class="confi_information" name="confi_information" id="confi_information">{{$terms_conditon_info->confi_information}}</textarea>
                                </div>




                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label" for="post">Disclaimer Of Warranties<span class="text-danger">*</span></label>
                                    <textarea class="disclaimer_warranty" name="disclaimer_warranty" id="disclaimer_warranty">{{$terms_conditon_info->disclaimer_warranty}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="post">Indemnification<span class="text-danger">*</span></label>
                                    <textarea class="indemnification" name="indemnification" id="indemnification">{{$terms_conditon_info->indemnification}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="post">Limitations Of Liablity<span class="text-danger">*</span></label>
                                    <textarea class="limit_liablity" name="limit_liablity" id="limit_liablity">{{$terms_conditon_info->limit_liablity}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="post">Software Licenses<span class="text-danger">*</span></label>
                                    <textarea class="software_license" name="software_license" id="software_license">{{$terms_conditon_info->software_license}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="post">RBI Disclaimer<span class="text-danger">*</span></label>
                                    <textarea class="disclaimer_rbi" name="disclaimer_rbi" id="disclaimer_rbi">{{$terms_conditon_info->disclaimer_rbi}}</textarea>
                                </div>

                            </div>






                        </div>
                    </div>
                    <div class="card-footer text-right">
                        <button class="btn btn-primary btn-lg btn-block" type="submit">{{ __('Update') }}</button>
                        {{-- <a href="{{route('dashboard')}}" class="btn btn-secondary" type="reset">{{ __('Cancel') }}</a> --}}
                    </div>
                </form>
            </div>
        </div>
    </div>


</div>

@endsection

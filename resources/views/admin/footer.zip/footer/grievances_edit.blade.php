@extends('layouts.admin')
@section('content')

<style>
    .size-16{
        width: 16px;
        height: 16px;
    }
    label{
    font-weight: 700;
    color: #2c2e3e;
}
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 m-b-30">
            <div class="d-block d-lg-flex flex-nowrap align-items-center">
                <div class="page-title mr-4 pr-4 border-right">
                    <h1>{{$footer_title}}</h1>
                </div>
                <div class="breadcrumb-bar align-items-center">
                    <nav>
                        <ol class="breadcrumb p-0 m-b-0">
                            <li class="breadcrumb-item">
                                <a href="{{ url('dashboard') }}"><i class="ti ti-home"></i></a>
                            </li>
                            <li class="breadcrumb-item active text-primary" aria-current="page">{{$update_title}}</li>
                        </ol>
                    </nav>
                </div>
                
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card py-5">
                <div class="col-12">
                    @include('inc.messages')
                </div>

                <form class="validate-form" method="POST" action="{{ route('grievance_redressal_policy.update') }}" enctype="multipart/form-data">
                    @csrf

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">

                                <div class="form-group">
                                    <label class="control-label" for="">Introduction<span class="text-danger">*</span></label>
                                    <textarea class="introduction" name="introduction" id="introduction">{{$grievance_info->introduction}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="post">Applicability Of The Policy<span class="text-danger">*</span></label>
                                    <textarea class="apps_of_policy" name="apps_of_policy" id="apps_of_policy">{{$grievance_info->apps_of_policy}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="post">Process To Handle Customer Complaints/Grievances<span class="text-danger">*</span></label>
                                    <textarea class="process_of_handle" name="process_of_handle" id="process_of_handle">{{$grievance_info->process_of_handle}}</textarea>
                                </div>
                                 <div class="form-group">
                                    <label class="control-label" for="post">Branch Requirements<span class="text-danger">*</span></label>
                                    <textarea class="branch_require" name="branch_require" id="branch_require">{{$grievance_info->branch_require}}</textarea>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label" for="post">Registration Of Complaints And Time Frame<span class="text-danger">*</span></label>
                                    <textarea class="registration_of_complaint" name="registration_of_complaint" id="registration_of_complaint">{{$grievance_info->registration_of_complaint}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="post">Interaction With Customers<span class="text-danger">*</span></label>
                                    <textarea class="interaction_with_customers" name="interaction_with_customers" id="interaction_with_customers">{{$grievance_info->interaction_with_customers}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="post">Sensitizing Operating Staff On Handling Complaints<span class="text-danger">*</span></label>
                                    <textarea class="operating_staff" name="operating_staff" id="operating_staff">{{$grievance_info->operating_staff}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="post">Escalation Of Complaint To Reserve Bank Of India<span class="text-danger">*</span></label>
                                    <textarea class="esclation_of_complaint" name="esclation_of_complaint" id="esclation_of_complaint">{{$grievance_info->esclation_of_complaint}}</textarea>
                                </div>


                            </div>






                        </div>
                    </div>
                    <div class="card-footer text-right">
                        <button class="btn btn-primary btn-lg btn-block" type="submit">{{ __('Update') }}</button>
                        {{-- <a href="{{route('dashboard')}}" class="btn btn-secondary" type="reset">{{ __('Cancel') }}</a> --}}
                    </div>
                </form>
            </div>
        </div>
    </div>


</div>

@endsection
